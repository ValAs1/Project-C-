﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _00
{
    class Program
    {
        static void Main(string[] args)
        {
            //int n = int.Parse(Console.ReadLine());
            //int m = int.Parse(Console.ReadLine());
            //ass(n, m);
            //Console.ReadLine();\
            //Console.WriteLine("n");
            // int n = int.Parse(Console.ReadLine());
            //int k = int.Parse(Console.ReadLine());

            //int[] arr = new int[5]
            //    {5,8,9,8,2};

            bool tr = ass(new[] { 10, 11, 12, 14 }, 11);
            Console.WriteLine(tr);
            //for (int i = 0; i < n; i++)
            //{
            //    for (int j = 0; j < n; j++)
            //    {

            //    }
            //}
        }

        static bool ass(int[] a, int k)
        {
        
         for (int i = 0; i<a.Length; i++)
	     {
                if (a[i] == k)
                {
                    return true;
                }
         }
         return false;
        }

////static void   ass(int n, int m)
        ////{
        ////    if(n<=m)
        ////    {
        ////        for (int i = n; i <= m; i++)
        ////        {
                   
        ////            Console.WriteLine(i);
        ////        }
              
        ////    }
        ////    else if(m<n)
        ////    {
        ////        for (int j = m; j <= n; j++)
        ////        {
        ////            Console.WriteLine(j);
        ////        }
        ////    }
        ////}

        

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            bool tr = ass(new[] { 10, 11, 12, 14 }, 11);
            Console.WriteLine(tr);
        }
        static bool ass(int[] a, int k)
        {
        
         for (int i = 0; i<a.Length; i++)
	         {
              if(a[i]==k)
             { 
                 return true;
		    	}
             }
         return false;
        }
    }
}
